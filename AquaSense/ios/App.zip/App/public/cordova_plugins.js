
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "cordova-plugin-ble-central.ble",
          "file": "plugins/cordova-plugin-ble-central/www/ble.js",
          "pluginId": "cordova-plugin-ble-central",
        "clobbers": [
          "ble"
        ]
        },
      {
          "id": "cordova-plugin-bluetoothle.BluetoothLe",
          "file": "plugins/cordova-plugin-bluetoothle/www/bluetoothle.js",
          "pluginId": "cordova-plugin-bluetoothle",
        "clobbers": [
          "window.bluetoothle"
        ]
        },
      {
          "id": "cordova-plugin-bluetooth-serial.bluetoothSerial",
          "file": "plugins/cordova-plugin-bluetooth-serial/www/bluetoothSerial.js",
          "pluginId": "cordova-plugin-bluetooth-serial",
        "clobbers": [
          "window.bluetoothSerial"
        ]
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "cordova-plugin-ble-central": "1.2.2",
      "cordova-plugin-bluetooth-serial": "0.4.7",
      "cordova-plugin-bluetoothle": "4.5.5"
    };
    // BOTTOM OF METADATA
    });
    